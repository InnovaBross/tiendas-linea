<?php
const BASE_URL = "http://localhost/AMACCS/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "AMACCS";
const CHARSET = "charset=utf8";
const TITLE = "TIENDA ONLINE";
const MONEDA = "USD";
const CLIENT_ID = "";

const USER_SMTP = "Tu correo";
const PASS_SMTP = "contraseña generada para esta aplicacion";
const PUERTO_SMTP = 465;
const HOST_SMTP = "smtp.gmail.com";
?>
