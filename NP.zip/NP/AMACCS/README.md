# Tienda-online-php-mvc-y-mysql
![tienda] https://github.com/InnovaBross/tiendas-linea.git

## Configuración

Instalación de Phpmailer

```bash
  composer install
```
    
## Credenciales de acceso
- Email: innovabross@gmail.com
- Clave: 12345
